import express from 'express';
import multer from 'multer';
import { processDocument } from '../services/documentAI.js';
import { extractInvoiceData } from '../utils/invoiceParser.js';
import { createExcel } from '../services/excelGenerator.js';

const router = express.Router();
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

router.post('/process', upload.single('invoice'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const result = await processDocument(req.file);
    const invoiceData = extractInvoiceData(result);
    const excelBuffer = createExcel(invoiceData);

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=invoice-data.xlsx');
    res.send(Buffer.from(excelBuffer));
  } catch (error) {
    console.error('Route handler error:', error);
    res.status(500).json({ 
      error: 'Error processing invoice',
      message: error.message 
    });
  }
});

export default router;