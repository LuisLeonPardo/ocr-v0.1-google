export function extractInvoiceData(document) {
  try {
    const { entities } = document.document;
    const invoiceData = {
      invoiceNumber: '',
      date: '',
      totalAmount: '',
      vendor: '',
      items: [],
    };

    entities.forEach((entity) => {
      switch (entity.type) {
        case 'invoice_id':
          invoiceData.invoiceNumber = entity.mentionText;
          break;
        case 'invoice_date':
          invoiceData.date = entity.mentionText;
          break;
        case 'total_amount':
          invoiceData.totalAmount = entity.mentionText;
          break;
        case 'supplier_name':
          invoiceData.vendor = entity.mentionText;
          break;
        case 'line_item':
          invoiceData.items.push({
            description: entity.properties.find(p => p.type === 'description')?.mentionText || '',
            quantity: entity.properties.find(p => p.type === 'quantity')?.mentionText || '',
            amount: entity.properties.find(p => p.type === 'amount')?.mentionText || '',
          });
          break;
      }
    });

    return invoiceData;
  } catch (error) {
    console.error('Invoice parsing error:', error);
    throw new Error('Failed to parse invoice data');
  }
}