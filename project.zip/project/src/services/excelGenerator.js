import * as XLSX from 'xlsx';

export function createExcel(invoiceData) {
  try {
    const wb = XLSX.utils.book_new();
    
    // Create summary sheet
    const summaryData = [
      ['Invoice Number', invoiceData.invoiceNumber],
      ['Date', invoiceData.date],
      ['Vendor', invoiceData.vendor],
      ['Total Amount', invoiceData.totalAmount],
    ];
    const summaryWs = XLSX.utils.aoa_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(wb, summaryWs, 'Summary');

    // Create items sheet
    const itemsData = [
      ['Description', 'Quantity', 'Amount'],
      ...invoiceData.items.map(item => [
        item.description,
        item.quantity,
        item.amount,
      ]),
    ];
    const itemsWs = XLSX.utils.aoa_to_sheet(itemsData);
    XLSX.utils.book_append_sheet(wb, itemsWs, 'Items');

    return XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  } catch (error) {
    console.error('Excel generation error:', error);
    throw new Error('Failed to generate Excel file');
  }
}