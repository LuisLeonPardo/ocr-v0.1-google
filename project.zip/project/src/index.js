import express from 'express';
import cors from 'cors';
import path from 'path';
import { config, __dirname } from './config/index.js';
import invoiceRoutes from './routes/invoice.js';

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Routes
app.use('/api/invoice', invoiceRoutes);

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../../public/index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: 'Internal Server Error',
    message: err.message
  });
});

app.listen(config.port, () => {
  console.log(`Server running at http://localhost:${config.port}`);
});